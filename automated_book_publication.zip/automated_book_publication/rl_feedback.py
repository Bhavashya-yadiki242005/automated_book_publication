import random

def rl_feedback(text):
    # Simulate human feedback score between 1-10
    score = random.randint(5, 10)
    print(f"🔄 RL Feedback Score: {score}/10")

    if score < 7:
        print("🔁 Re-spinning text to improve quality...")
        improved_text = text.replace("THE", "The").replace("the", "The")
        return improved_text
    return text

if __name__ == "__main__":
    with open("chapter1_spun.txt", "r", encoding="utf-8") as f:
        content = f.read()
    final_text = rl_feedback(content)

    with open("chapter1_rl_final.txt", "w", encoding="utf-8") as f:
        f.write(final_text)

    print("✅ RL-based improved version saved as chapter1_rl_final.txt")
