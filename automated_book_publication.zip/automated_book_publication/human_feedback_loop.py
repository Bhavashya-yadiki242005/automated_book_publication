print("Human-in-the-Loop Review System")

input_file = 'chapter1_spun.txt'
output_file = 'chapter1_final.txt'

try:
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()

    print("\n--- AI Generated Text Preview ---\n")
    print(content[:1000] + ('...\n[Content Truncated]' if len(content) > 1000 else ''))

    print("\nYou can edit the text in this console. Press Enter to keep as-is.")
    user_edit = input("\nEnter your edits (or leave blank to accept): ")

    # ✅ Always save final text (even if blank)
    final_text = user_edit if user_edit.strip() else content

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(final_text)

    print(f'✅ Final approved version saved as {output_file}')

except FileNotFoundError:
    print('❌ chapter1_spun.txt not found. Please run the AI Writer first.')
