import chromadb
from chromadb.utils import embedding_functions

client = chromadb.Client()
collection = client.get_or_create_collection("book_versions")

def save_version(version_name, text):
    collection.add(documents=[text], metadatas=[{"version": version_name}], ids=[version_name])

def search_versions(query):
    return collection.query(query_texts=[query], n_results=2)

if __name__ == "__main__":
    print("🔍 Searching for versions containing keyword: sunrise")
    result = search_versions("sunrise")
    print(result)
