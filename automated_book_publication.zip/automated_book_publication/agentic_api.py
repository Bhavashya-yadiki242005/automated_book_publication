from fastapi import FastAPI
from fastapi.responses import FileResponse
import os
import speech_recognition as sr
import pyttsx3

# ✅ 1. Improved API title and description
app = FastAPI(
    title="Automated Book Publication System",
    description="This API automates the process of scraping book chapters, processing with AI, enabling human review, and storing versions with RL feedback and voice support.",
    version="1.0.0",
    docs_url="/project-api",
    redoc_url=None
)

# ✅ 2. Scrape Chapter
@app.get("/scrape", tags=["Scraping"])
def scrape_chapter():
    """Scrapes a chapter from the specified online source and saves text and image."""
    os.system("python scrape_and_screenshot.py")
    return {"message": "Chapter successfully scraped and saved (text and screenshot)."}

# ✅ 3. AI Writer
@app.get("/ai_writer", tags=["AI Processing"])
def ai_writer():
    """Processes the scraped text using AI and saves a refined version."""
    os.system("python ai_writer_reviewer.py")
    return {"message": "AI processing completed. Output saved for review."}

# ✅ 4. Human Review
@app.get("/human_review", tags=["Human Review"])
def human_review():
    """Allows manual human edits before finalizing the text."""
    os.system("python human_feedback_loop.py")
    return {"message": "Human review step completed. Final version saved."}

# ✅ 5. Download Final File
@app.get("/download_final", tags=["Download"])
def download_final():
    """Download the final approved version of the chapter."""
    file_path = "chapter1_final.txt"
    if os.path.exists(file_path):
        return FileResponse(file_path, filename="chapter1_final.txt")
    return {"message": "Final reviewed file not found. Please complete the review step first."}

# ✅ 6. Voice Command
@app.get("/voice_command", tags=["Voice Support"])
def voice_command():
    """Accepts a voice command and converts it to text."""
    recognizer = sr.Recognizer()
    engine = pyttsx3.init()
    try:
        with sr.Microphone() as source:
            print("🎤 Listening for voice command...")
            audio = recognizer.listen(source, timeout=40)
            command = recognizer.recognize_google(audio)
            engine.say("You said: " + command)
            engine.runAndWait()
            return {"message": f"Voice command recognized: {command}"}
    except Exception as e:
        return {"message": f"Voice command failed: {str(e)}"}

# ✅ 7. RL Feedback Endpoint
@app.get("/rl_feedback", tags=["Reinforcement Learning Feedback"])
def rl_feedback():
    """Simulates collecting user feedback for RL-based model improvement."""
    # Placeholder: Here, you could store user rating for future RL fine-tuning
    feedback_message = "Reinforcement Learning feedback received and logged."
    return {"message": feedback_message}
