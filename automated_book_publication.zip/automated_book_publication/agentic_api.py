from fastapi import FastAPI
from fastapi.responses import FileResponse
import os

# ✅ 1. Changed title, description, version to make it professional
app = FastAPI(
    title="Automated Book Publication System",
    description=(
        "This API allows you to scrape book chapters from Wikisource, "
        "process them using AI rewriting, perform human review, and manage versioning."
    ),
    version="1.0.0",
    docs_url="/project-api",   # ✅ 2. Changed docs URL
    redoc_url=None
)

# ✅ 3. Added tags for better grouping in UI

@app.get("/scrape", tags=["Scraping"])
def scrape_chapter():
    """Scrapes a chapter from the specified online source and saves text and image."""
    os.system("python scrape_and_screenshot.py")
    return {"message": "Chapter successfully scraped and saved (text and screenshot)."}

@app.get("/ai_writer", tags=["AI Processing"])
def ai_writer():
    """Processes the scraped text using AI and saves a refined version."""
    os.system("python ai_writer_reviewer.py")
    return {"message": "AI processing completed. Output saved for review."}

@app.get("/human_review", tags=["Human Review"])
def human_review():
    """Allows manual human edits before finalizing the text."""
    os.system("python human_feedback_loop.py")
    return {"message": "Human review step completed. Final version saved."}

@app.get("/download_final", tags=["Download"])
def download_final():
    """Download the final approved version of the chapter."""
    file_path = "chapter1_final.txt"
    if os.path.exists(file_path):
        return FileResponse(file_path, filename="chapter1_final.txt")
    return {"message": "Final reviewed file not found. Please complete the review step first."}
