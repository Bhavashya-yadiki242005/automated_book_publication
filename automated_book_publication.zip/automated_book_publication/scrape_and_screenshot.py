from playwright.sync_api import sync_playwright
import time

URL = "https://en.wikisource.org/wiki/The_Gates_of_Morning/Book_1/Chapter_1"

def scrape_content():
    print("🚀 Launching browser...")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)  # show browser
        page = browser.new_page()
        print("🌐 Navigating to:", URL)
        page.goto(URL, timeout=60000)
        time.sleep(5)
        print("📜 Extracting content...")
        try:
            content = page.locator('#mw-content-text').inner_text()
        except Exception as e:
            print("❌ Error extracting content:", e)
            content = ""
        print("📸 Taking screenshot...")
        page.screenshot(path='chapter1.png')
        browser.close()
    return content

if __name__ == '__main__':
    print("🔄 Starting scraping process...")
    text = scrape_content()
    if text:
        with open('chapter1.txt', 'w', encoding='utf-8') as f:
            f.write(text)
        print("✅ Scraping complete. Text and screenshot saved.")
    else:
        print("⚠️ No text extracted. Please check the selector or website loading.")
