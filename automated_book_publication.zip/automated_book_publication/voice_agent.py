import speech_recognition as sr
import os

def listen_and_execute():
    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    print("🎤 Say a command (scrape, write, review, download)...")
    with mic as source:
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        command = recognizer.recognize_google(audio).lower()
        print(f"✅ You said: {command}")

        if "scrape" in command:
            os.system("python scrape_and_screenshot.py")
        elif "write" in command:
            os.system("python ai_writer_reviewer.py")
        elif "review" in command:
            os.system("python human_feedback_loop.py")
        elif "download" in command:
            print("📂 Final file is chapter1_final.txt")
        else:
            print("❌ Command not recognized.")

    except sr.UnknownValueError:
        print("⚠️ Could not understand audio.")
    except sr.RequestError:
        print("❌ Speech recognition service unavailable.")

if __name__ == "__main__":
    listen_and_execute()
