import openai

def ai_spin_text(input_text):
    print("🔄 Spinning text...")
    try:
        spun_text = input_text.replace('the', 'THE').replace('The', 'THE')
        return '🔄 AI-Spun Version:\n' + spun_text
    except Exception as e:
        return f'Error during AI processing: {e}'

if __name__ == '__main__':
    print("🚀 Starting AI Writer...")
    try:
        with open('chapter1.txt', 'r', encoding='utf-8') as f:
            content = f.read()
        print("📜 Original text length:", len(content))
        spun_result = ai_spin_text(content)
        with open('chapter1_spun.txt', 'w', encoding='utf-8') as f:
            f.write(spun_result)
        print('✅ AI Writing and Review complete. File saved as chapter1_spun.txt')
    except FileNotFoundError:
        print('❌ chapter1.txt not found. Please run the scraper first.')
