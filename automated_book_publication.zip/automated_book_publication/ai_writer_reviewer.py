import openai
import os

# Set your OpenAI API Key
openai.api_key = os.getenv("OPENAI_API_KEY")

def ai_spin_text(input_text):
    try:
        # Call GPT model to rewrite text
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a book editor rewriting text to improve grammar, clarity, and style."},
                {"role": "user", "content": f"Rewrite this book text for improved readability:\n\n{input_text}"}
            ],
            max_tokens=1500
        )

        spun_text = response.choices[0].message.content

        # Calculate a basic reward score (readability)
        reward_score = calculate_reward(input_text, spun_text)

        return f"AI-Spun Version (Reward Score: {reward_score:.2f}):\n\n{spun_text}"

    except Exception as e:
        return f"Error during AI processing: {e}"

def calculate_reward(original, rewritten):
    """
    Basic RL-inspired reward:
    - Penalize if text is too short or too long compared to original
    - Reward based on length similarity
    """
    orig_len = len(original.split())
    new_len = len(rewritten.split())
    length_ratio = min(new_len / orig_len, orig_len / new_len)
    reward = max(0, min(1, length_ratio))  # Keep between 0 and 1
    return reward

if __name__ == '__main__':
    try:
        with open('chapter1.txt', 'r', encoding='utf-8') as f:
            content = f.read()

        spun_result = ai_spin_text(content)

        with open('chapter1_spun.txt', 'w', encoding='utf-8') as f:
            f.write(spun_result)

        print("AI Writing and Review complete. File saved as chapter1_spun.txt")

    except FileNotFoundError:
        print("chapter1.txt not found. Please run the scraper first.")
